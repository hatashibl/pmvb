<?php
// modules/ajax_handler.php - Xử lý Backend (Đã FIX lỗi edit_van_ban_den thiếu ID và lỗi kết nối chung)

// =========================================================
// 1. CÁC HÀM TIỆN ÍCH (UTILITY FUNCTIONS)
// =========================================================

function convert_date_to_sql($date_str) {
    if (!$date_str) return null;
    $dt = DateTime::createFromFormat('d/m/Y', $date_str);
    return $dt ? $dt->format('Y-m-d') : null;
}

function clean_string_for_filename($string) {
    $string = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
    $string = strtolower($string);
    $string = preg_replace('/[^a-z0-9\s]/', '-', $string);
    $string = preg_replace('/[\s-]+/', '-', $string);
    $string = substr($string, 0, 50); 
    return trim($string, '-');
}

function get_loai_vb_short($loai_vb_id, $pdo) {
    $stmt = $pdo->prepare("SELECT ky_hieu_ngan FROM loai_van_ban WHERE id = ?");
    $stmt->execute([$loai_vb_id]);
    $ky_hieu = $stmt->fetchColumn();
    return $ky_hieu ?: 'VB'; 
}


// =========================================================
// 2. PHẦN KHỞI TẠO VÀ XỬ LÝ ACTION
// =========================================================

require_once '../core/auth.php'; 

if (isset($_GET['action'])) {
    $action = $_GET['action'];
} elseif (isset($_POST['action'])) {
    $action = $_POST['action'];
} else {
    $action = '';
}

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Bạn cần đăng nhập để thực hiện thao tác này.']);
    exit;
}

global $pdo;
$current_user_id = $_SESSION['user_id'];


switch ($action) {
    
    // =========================================================
    // HÀNH ĐỘNG 1: THÊM VĂN BẢN ĐẾN (FIX LỖI KẾT NỐI CHUNG)
    // =========================================================
case 'add_van_ban_den':
    // Sử dụng hàm convert_date_to_sql và clean_string_for_filename đã định nghĩa ở trên

    // 1. Lấy dữ liệu và Chuẩn hóa
    $so_den = trim($_POST['so_den'] ?? '');
    $nam_den = (int)($_POST['nam_den'] ?? 0);
    $so_van_ban = trim($_POST['so_van_ban'] ?? '');
    $ngay_thang_vb_str = trim($_POST['ngay_thang_vb'] ?? '');
    $noi_ban_hanh = trim($_POST['noi_ban_hanh'] ?? '');
    $loai_vb_id = (int)($_POST['loai_vb_id'] ?? 0);
    $trich_yeu = trim($_POST['trich_yeu'] ?? '');
    $de_xuat_xu_ly = trim($_POST['de_xuat_xu_ly'] ?? '');
    $nguoi_nhap_id = $current_user_id; // Đã lấy ở trên
    
    // Convert date to SQL format
    $ngay_thang_vb = convert_date_to_sql($ngay_thang_vb_str);
    
    // Lấy thông tin file
    $file_info = $_FILES['file_dinh_kem'] ?? null;
    $file_dinh_kem_db = null;

    // 2. VALIDATION (Kiểm tra đầy đủ các trường bắt buộc + KHÔNG kiểm tra Người nhận)
    $errors = [];
    
    if (empty($so_den) || !is_numeric($so_den) || $so_den <= 0) {
        $errors[] = "Số đến không hợp lệ (chỉ được nhập số > 0).";
    }
    if ($loai_vb_id <= 0) {
        $errors[] = "Loại Văn bản.";
    }
    if (empty($so_van_ban)) {
        $errors[] = "Số Văn bản.";
    }
    if (empty($ngay_thang_vb_str) || !$ngay_thang_vb) {
        $errors[] = "Ngày Văn bản (hoặc định dạng DD/MM/YYYY không hợp lệ).";
    }
    if (empty($noi_ban_hanh)) {
        $errors[] = "Nơi ban hành.";
    }
    if (empty($trich_yeu)) {
        $errors[] = "Trích yếu nội dung.";
    }
    if (empty($de_xuat_xu_ly)) {
        $errors[] = "Đề xuất xử lý.";
    }
    
    // LƯU Ý QUAN TRỌNG: Đã loại bỏ kiểm tra Người nhận để KHẮC PHỤC LỖI CỦA BẠN.
    
    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Vui lòng điền đầy đủ các trường bắt buộc và hợp lệ: ' . implode(', ', $errors)]);
        exit;
    }
    
    // 3. Xử lý File đính kèm
    if ($file_info && $file_info['error'] === UPLOAD_ERR_OK) {
        $target_dir = '../assets/files/vb_den/';
        if (!is_dir($target_dir)) { mkdir($target_dir, 0777, true); }
        
        $extension = pathinfo($file_info['name'], PATHINFO_EXTENSION);
        // Tạo tên file từ trích yếu và số đến
        $base_name = clean_string_for_filename($trich_yeu); 
        $ten_file_moi = "{$base_name}-vbd-{$so_den}.{$extension}";
        $upload_path = $target_dir . $ten_file_moi;

        if (move_uploaded_file($file_info['tmp_name'], $upload_path)) {
            $file_dinh_kem_db = $ten_file_moi;
        } else {
            // Lỗi khi upload
            echo json_encode(['success' => false, 'message' => 'Lỗi khi upload file lên server.']);
            exit;
        }
    }

    // 4. Chèn dữ liệu vào VAN_BAN_DEN
    global $pdo;
    $pdo->beginTransaction();
    try {
        $sql = "INSERT INTO van_ban_den (so_den, nam_den, so_van_ban, ngay_thang_vb, noi_ban_hanh, loai_vb_id, trich_yeu, de_xuat_xu_ly, file_dinh_kem, nguoi_nhap_id) 
                VALUES (:so_den, :nam_den, :so_van_ban, :ngay_thang_vb, :noi_ban_hanh, :loai_vb_id, :trich_yeu, :de_xuat_xu_ly, :file_dinh_kem, :nguoi_nhap_id)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':so_den' => $so_den,
            ':nam_den' => $nam_den,
            ':so_van_ban' => $so_van_ban,
            ':ngay_thang_vb' => $ngay_thang_vb,
            ':noi_ban_hanh' => $noi_ban_hanh,
            ':loai_vb_id' => $loai_vb_id,
            ':trich_yeu' => $trich_yeu,
            ':de_xuat_xu_ly' => $de_xuat_xu_ly,
            ':file_dinh_kem' => $file_dinh_kem_db,
            ':nguoi_nhap_id' => $nguoi_nhap_id
        ]);

        $new_vb_id = $pdo->lastInsertId();
        
        $pdo->commit();

        // Trả về thành công và ID văn bản để có thể dùng cho modal Gửi sau này
        echo json_encode(['success' => true, 'message' => 'Thêm Văn bản Đến thành công!', 'vb_id' => $new_vb_id]);

    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Lỗi SQL khi thêm Văn bản Đến: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Lỗi CSDL khi lưu văn bản. Vui lòng kiểm tra log hệ thống.']);
    }
    exit;        
    // =========================================================
    // HÀNH ĐỘNG 2: CHỈNH SỬA VĂN BẢN (FIX LỖI THIẾU ID)
    // =========================================================
    case 'edit_van_ban_den':
        // FIX: Kiểm tra cả hai tên trường phổ biến nhất (id hoặc van_ban_id)
        $vb_id = (int)(isset($_POST['van_ban_id']) ? $_POST['van_ban_id'] : (isset($_POST['id']) ? $_POST['id'] : 0));
        
        $so_van_ban = trim(isset($_POST['so_van_ban']) ? $_POST['so_van_ban'] : '');
        $ngay_thang_vb = convert_date_to_sql(isset($_POST['ngay_thang_vb']) ? $_POST['ngay_thang_vb'] : '');
        $loai_vb_id = (int)(isset($_POST['loai_vb_id']) ? $_POST['loai_vb_id'] : 0);
        $noi_ban_hanh = trim(isset($_POST['noi_ban_hanh']) ? $_POST['noi_ban_hanh'] : '');
        $trich_yeu = trim(isset($_POST['trich_yeu']) ? $_POST['trich_yeu'] : '');
        $de_xuat_xu_ly = trim(isset($_POST['de_xuat_xu_ly']) ? $_POST['de_xuat_xu_ly'] : '');
        $so_den = (int)(isset($_POST['so_den']) ? $_POST['so_den'] : 0);
        $nam_den = (int)(isset($_POST['nam_den']) ? $_POST['nam_den'] : date('Y'));
        
        $recipients_str = trim(isset($_POST['recipients']) ? $_POST['recipients'] : ''); 
        $recipient_ids = array_filter(array_map('intval', explode(',', $recipients_str)));
        $delete_file = isset($_POST['delete_file']) && $_POST['delete_file'] == '1';
        $current_file_path = isset($_POST['current_file_path']) ? $_POST['current_file_path'] : null;

        if ($vb_id <= 0 || empty($so_van_ban) || $loai_vb_id <= 0 || empty($trich_yeu)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Lỗi: Dữ liệu chỉnh sửa không hợp lệ. Vui lòng kiểm tra ID, Số VB, Loại VB, Trích yếu.']);
            exit;
        }

        $file_path = $current_file_path;
        $current_year = date('Y');

        // --- Xử lý XÓA FILE cũ ---
        if ($delete_file && $current_file_path) {
            if (file_exists('../' . $current_file_path)) {
                unlink('../' . $current_file_path);
            }
            $file_path = null; 
        }

        // --- Xử lý File Upload MỚI ---
        if (isset($_FILES['file_dinh_kem']) && $_FILES['file_dinh_kem']['error'] === UPLOAD_ERR_OK) {
            
            // Xóa file cũ nếu có file mới được upload (nếu chưa bị xóa ở bước trên)
            if ($current_file_path && file_exists('../' . $current_file_path)) {
                unlink('../' . $current_file_path);
            }
            
            $root_upload_dir = '../'; 
            $upload_dir_relative = "van_ban_den/{$current_year}/";
            $upload_dir_full = $root_upload_dir . $upload_dir_relative;

            if (!is_dir($upload_dir_full)) { 
                if (!mkdir($upload_dir_full, 0777, true)) {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Lỗi: Không thể tạo thư mục lưu trữ file.']);
                    exit;
                }
            }
            
            $loai_vb_short = get_loai_vb_short($loai_vb_id, $pdo);
            $base_filename = "{$loai_vb_short}_{$so_van_ban}_" . clean_string_for_filename($trich_yeu);
            $file_extension = pathinfo($_FILES['file_dinh_kem']['name'], PATHINFO_EXTENSION);
            $new_file_name = $base_filename . '_' . time() . '.' . $file_extension;
            $file_temp_path = $upload_dir_full . $new_file_name;
            
            if (!move_uploaded_file($_FILES['file_dinh_kem']['tmp_name'], $file_temp_path)) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Lỗi lưu file đính kèm mới.']);
                exit;
            }
            
            $file_path = $upload_dir_relative . $new_file_name; 
        }

        // --- Bắt đầu Transaction CSDL ---
        $pdo->beginTransaction();
        try {
            // 1. UPDATE Văn bản vào bảng van_ban_den
            $sql_vb = "UPDATE van_ban_den SET
                so_van_ban = :so_vb, ngay_thang_vb = :ngay_vb, trich_yeu = :trich_yeu, 
                loai_vb_id = :loai_vb_id, noi_ban_hanh = :noi_bh, de_xuat_xu_ly = :de_xuat, 
                file_dinh_kem = :file_path, nam_den = :nam_den, so_den = :so_den, 
                ngay_cap_nhat = NOW()
                WHERE id = :vb_id";

            $stmt_vb = $pdo->prepare($sql_vb);
            $stmt_vb->execute([
                ':so_vb' => $so_van_ban,
                ':ngay_vb' => $ngay_thang_vb,
                ':trich_yeu' => $trich_yeu,
                ':loai_vb_id' => $loai_vb_id,
                ':noi_bh' => $noi_ban_hanh,
                ':de_xuat' => $de_xuat_xu_ly,
                ':file_path' => $file_path,
                ':nam_den' => $nam_den,
                ':so_den' => $so_den,
                ':vb_id' => $vb_id
            ]);

            // 2. Xử lý người nhận (Xóa và chèn lại)
            $pdo->prepare("DELETE FROM thong_bao_nguoi_nhan WHERE van_ban_den_id = ?")->execute([$vb_id]);

            $sql_notify = "INSERT INTO thong_bao_nguoi_nhan (
                van_ban_den_id, nguoi_gui_id, nguoi_nhan_id, noi_dung, trang_thai, thoi_gian_gui
            ) VALUES (
                :vb_id, :nguoi_gui, :nguoi_nhan, :noi_dung, 'chua_doc', NOW()
            )";
            $stmt_notify = $pdo->prepare($sql_notify);

            $noi_dung_thong_bao = "Văn bản Đến số **{$so_van_ban}** ({$trich_yeu}) đã được CẬP NHẬT và phân công cho bạn xử lý. Vui lòng kiểm tra.";

            foreach ($recipient_ids as $recipient_id) {
                $stmt_notify->execute([
                    ':vb_id' => $vb_id,
                    ':nguoi_gui' => $current_user_id,
                    ':nguoi_nhan' => $recipient_id,
                    ':noi_dung' => $noi_dung_thong_bao,
                ]);
            }

            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Chỉnh sửa văn bản đến và cập nhật người nhận thành công!']);
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            // Xóa file mới nếu lỗi CSDL
            if ($file_path && $file_path !== $current_file_path && file_exists('../' . $file_path)) {
                unlink('../' . $file_path);
            }
            error_log("Lỗi SQL khi chỉnh sửa VB Đến: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi CSDL (EDIT): ' . $e->getMessage()]); // Trả về thông báo lỗi chi tiết hơn
        }
        exit;
        
    case 'get_vb_detail_and_mark_read':
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Bạn cần đăng nhập.']);
            exit;
        }

        $vb_id = (int)(isset($_GET['vb_id']) ? $_GET['vb_id'] : 0);
        $message_id = (int)(isset($_GET['message_id']) ? $_GET['message_id'] : 0); 
        $current_user_id = $_SESSION['user_id'];
        
        if ($message_id <= 0 && $vb_id == 0) { 
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID tin nhắn không hợp lệ.']);
            exit;
        }

        $pdo->beginTransaction();
        $rows_affected = 0; 
        $van_ban = null; 
        $nguoi_gui_vb_info = null;
        $latest_message = null;
        $recipient_id_for_reply = 0;

        try {
            if ($vb_id > 0) {
                $sql_vb = "SELECT 
                            vbd.*, 
                            lvb.ten_loai_vb, 
                            u.ten_day_du AS nguoi_nhap_ten,
                            u.id AS nguoi_nhap_id_vb
                        FROM van_ban_den vbd
                        LEFT JOIN loai_van_ban lvb ON vbd.loai_vb_id = lvb.id
                        LEFT JOIN nguoi_dung u ON vbd.nguoi_nhap_id = u.id
                        WHERE vbd.id = ?";
                
                $stmt_vb = $pdo->prepare($sql_vb);
                $stmt_vb->execute([$vb_id]);
                $van_ban = $stmt_vb->fetch(PDO::FETCH_ASSOC);

                if ($van_ban) {
                    $van_ban['ngay_thang_vb_display'] = $van_ban['ngay_thang_vb'] ? date('d/m/Y', strtotime($van_ban['ngay_thang_vb'])) : '';
                    $recipient_id_for_reply = $van_ban['nguoi_nhap_id_vb'];
                    $nguoi_gui_vb_info = ['id' => $recipient_id_for_reply, 'ten_day_du' => $van_ban['nguoi_nhap_ten']];
                }
            } else {
                 $van_ban = ['trich_yeu' => 'Tin nhắn độc lập/Không liên quan đến VB'];
            }

            // Đánh dấu đã đọc
            $sql_mark_read = "UPDATE thong_bao_nguoi_nhan 
                              SET trang_thai = 'da_doc', thoi_gian_doc = NOW() 
                              WHERE van_ban_den_id = :vb_id AND nguoi_nhan_id = :user_id AND trang_thai = 'chua_doc'";
            $stmt_mark_read = $pdo->prepare($sql_mark_read);
            $stmt_mark_read->execute([':vb_id' => $vb_id, ':user_id' => $current_user_id]);
            
            $rows_affected = $stmt_mark_read->rowCount();
            $is_newly_read = $rows_affected > 0; 

            // Lấy Thread
            if ($vb_id > 0) {
                $thread_condition = "tn.van_ban_den_id = ?";
                $thread_param = [$vb_id];
            } else {
                $thread_condition = "tn.van_ban_den_id = 0 AND (tn.nguoi_nhan_id = ? OR tn.nguoi_gui_id = ?)"; 
                $thread_param = [$current_user_id, $current_user_id];
            }

            $sql_thread = "SELECT 
                            tn.id, tn.nguoi_gui_id, tn.noi_dung, tn.trang_thai, tn.thoi_gian_gui, tn.file_dinh_kem_reply,
                            u.ten_day_du AS nguoi_gui_ten
                           FROM thong_bao_nguoi_nhan tn
                           LEFT JOIN nguoi_dung u ON tn.nguoi_gui_id = u.id
                           WHERE {$thread_condition}
                           ORDER BY tn.thoi_gian_gui ASC";
            
            $stmt_thread = $pdo->prepare($sql_thread);
            $stmt_thread->execute($thread_param);
            $thread = $stmt_thread->fetchAll(PDO::FETCH_ASSOC);
            
            // Lấy tin nhắn mới nhất
            if (!empty($thread)) {
                 foreach ($thread as &$msg) {
                     if ($msg['id'] == $message_id) {
                         if ($is_newly_read && $msg['trang_thai'] === 'chua_doc' && $msg['nguoi_nhan_id'] == $current_user_id) {
                             $msg['trang_thai'] = 'da_doc';
                         }
                         $latest_message = $msg;
                         break;
                     }
                 }
                 unset($msg); 
            }
            
            if ($vb_id == 0 && $latest_message) {
                 $recipient_id_for_reply = $latest_message['nguoi_gui_id'];
                 $stmt_nguoi_gui = $pdo->prepare("SELECT id, ten_day_du FROM nguoi_dung WHERE id = ?");
                 $stmt_nguoi_gui->execute([$recipient_id_for_reply]);
                 $nguoi_gui_vb_info = $stmt_nguoi_gui->fetch(PDO::FETCH_ASSOC);
            }
            
            if (!$nguoi_gui_vb_info && $vb_id == 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy thông tin Người gửi để trả lời.']);
                exit;
            }


            $pdo->commit();

            echo json_encode([
                'success' => true,
                'van_ban' => $van_ban, 
                'nguoi_gui' => $nguoi_gui_vb_info,
                'latest_message' => $latest_message,
                'thread' => $thread,
                'is_newly_read' => $is_newly_read,
                'messages_marked_read' => $rows_affected,
            ]);

        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Lỗi SQL khi xem chi tiết/đánh dấu đã đọc: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi CSDL khi xử lý thông báo.']);
        }
        exit;
        
    case 'get_van_ban_den_detail':
        $vb_id = (int)(isset($_GET['vb_id']) ? $_GET['vb_id'] : 0);

        if ($vb_id <= 0) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID văn bản không hợp lệ.']);
            exit;
        }

        try {
            $sql = "SELECT 
                        vbd.*, 
                        lvb.ten_loai_vb, 
                        u.ten_day_du AS nguoi_nhap_ten
                    FROM van_ban_den vbd
                    LEFT JOIN loai_van_ban lvb ON vbd.loai_vb_id = lvb.id
                    LEFT JOIN nguoi_dung u ON vbd.nguoi_nhap_id = u.id
                    WHERE vbd.id = ?";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$vb_id]);
            $van_ban = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($van_ban) {
                $van_ban['ngay_thang_vb_display'] = $van_ban['ngay_thang_vb'] ? date('d/m/Y', strtotime($van_ban['ngay_thang_vb'])) : '';
                echo json_encode(['success' => true, 'data' => $van_ban]);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Không tìm thấy văn bản.']);
            }
        } catch (PDOException $e) {
            error_log("Lỗi SQL khi lấy chi tiết VB: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Lỗi CSDL khi lấy chi tiết văn bản.']);
        }
        exit;

    case 'reply_van_ban':
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Bạn cần đăng nhập.']);
            exit;
        }

        $current_user_id = $_SESSION['user_id'];
        
        $vb_id = (int)(isset($_POST['original_vb_id']) ? $_POST['original_vb_id'] : 0);
        $recipient_id = (int)(isset($_POST['recipient_id']) ? $_POST['recipient_id'] : 0);
        $reply_message = trim(isset($_POST['reply_message']) ? $_POST['reply_message'] : '');
        $current_year = date('Y');

        if ($recipient_id <= 0 || empty($reply_message)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Người nhận hoặc nội dung trả lời không được để trống.']);
            exit;
        }

        // --- Xử lý File đính kèm Trả lời ---
        $file_reply_path = null;
        if (isset($_FILES['reply_file']) && $_FILES['reply_file']['error'] === UPLOAD_ERR_OK) {
            
            $root_upload_dir = '../'; 
            $upload_dir_relative = "van_ban_tra_loi/{$current_year}/";
            $upload_dir_full = $root_upload_dir . $upload_dir_relative;
            
            if (!is_dir($upload_dir_full)) { 
                if (!mkdir($upload_dir_full, 0777, true)) {
                    http_response_code(500);
                    echo json_encode(['success' => false, 'message' => 'Lỗi: Không thể tạo thư mục lưu trữ file trả lời.']);
                    exit;
                }
            }
            
            $file_extension = pathinfo($_FILES['reply_file']['name'], PATHINFO_EXTENSION);
            $base_filename = "reply_{$vb_id}_{$current_user_id}_{$recipient_id}_" . time();
            $new_file_name = $base_filename . '.' . $file_extension;
            $file_temp_path = $upload_dir_full . $new_file_name;
            
            if (!move_uploaded_file($_FILES['reply_file']['tmp_name'], $file_temp_path)) {
                http_response_code(500);
                error_log("Lỗi move file trả lời: " . $file_temp_path);
                echo json_encode(['success' => false, 'message' => 'Lỗi lưu file đính kèm trả lời.']);
                exit;
            }
            
            $file_reply_path = $upload_dir_relative . $new_file_name; 
        }


        // --- INSERT TIN NHẮN TRẢ LỜI ---
        $pdo->beginTransaction();
        try {
            $sql = "INSERT INTO thong_bao_nguoi_nhan (
                van_ban_den_id, nguoi_gui_id, nguoi_nhan_id, noi_dung, file_dinh_kem_reply, trang_thai, thoi_gian_gui
            ) VALUES (
                :vb_id, :nguoi_gui, :nguoi_nhan, :noi_dung, :file_reply, 'chua_doc', NOW()
            )";

            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':vb_id', $vb_id, PDO::PARAM_INT);
            $stmt->bindParam(':nguoi_gui', $current_user_id, PDO::PARAM_INT); 
            $stmt->bindParam(':nguoi_nhan', $recipient_id, PDO::PARAM_INT); 
            $stmt->bindParam(':noi_dung', $reply_message);
            $stmt->bindParam(':file_reply', $file_reply_path);
            
            $stmt->execute();

            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Gửi trả lời thành công!']);

        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Lỗi SQL khi gửi trả lời tin nhắn: " . $e->getMessage());
            
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Đã xảy ra lỗi trong quá trình xử lý CSDL khi gửi trả lời.']);
        }
        exit;

    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Hành động không hợp lệ.']);
        exit;
}
?>