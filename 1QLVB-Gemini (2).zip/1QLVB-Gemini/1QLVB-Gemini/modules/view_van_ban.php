// ... trong phần hiển thị chi tiết VB Đi
<a href="modules/word_generator.php?type=vb_di&id=<?= $vb_id ?>" class="btn btn-info">
    <i class="fas fa-file-word"></i> Xuất File Word
</a>
// ...