<?php
// modules/van_ban_den_handler.php
require_once '../core/auth.php';
check_login();

// Hàm chuẩn hóa chuỗi (tạo slug không dấu)
function slugify($text) {
    // ... (Hàm slugify giống như van_ban_di_handler.php)
    $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
    $text = preg_replace('/[^a-zA-Z0-9]/', '', $text);
    return strtolower($text);
}

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST['action'] == 'save') {
    // 1. Lấy dữ liệu
    $so_den = (int)$_POST['so_den'];
    $nam_den = (int)$_POST['nam_den'];
    $so_van_ban = trim($_POST['so_van_ban']);
    $ngay_thang_vb = $_POST['ngay_thang_vb'];
    $loai_vb_id = (int)$_POST['loai_vb_id'];
    $trich_yeu = $_POST['trich_yeu'];
    $de_xuat_xu_ly = $_POST['de_xuat_xu_ly'];
    $nguoi_nhap_id = $_SESSION['user_id'];

    // 2. Validation cơ bản (Nên thực hiện kiểm tra sâu hơn)
    if (empty($so_den) || empty($ngay_thang_vb) || empty($loai_vb_id) || empty($trich_yeu)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Vui lòng điền đầy đủ các trường bắt buộc.']);
        exit;
    }

    $pdo->beginTransaction();
    try {
        // Lấy tên viết tắt để đổi tên file
        $stmt_vb_info = $pdo->prepare("SELECT ten_viet_tat FROM loai_van_ban WHERE id = ?");
        $stmt_vb_info->execute([$loai_vb_id]);
        $vb_info = $stmt_vb_info->fetch(PDO::FETCH_ASSOC);
        $ten_viet_tat = $vb_info['ten_viet_tat'] ?? 'VB';
        
        // 3. Xử lý File Upload và Đổi tên File
        $file_dinh_kem_db = NULL;
        if (isset($_FILES['file_dinh_kem']) && $_FILES['file_dinh_kem']['error'] == UPLOAD_ERR_OK) {
            $file_info = $_FILES['file_dinh_kem'];
            $file_ext = pathinfo($file_info['name'], PATHINFO_EXTENSION);
            
            // TT123_020125_ToTrinhDaiHoi
            $ten_file_moi = 
                $ten_viet_tat . 
                $so_van_ban . 
                '_' . date('dmy', strtotime($ngay_thang_vb)) . 
                '_' . substr(slugify(strip_tags($trich_yeu)), 0, 50) . 
                '.' . $file_ext;
            
            $upload_path = '../assets/files/vb_den/' . $ten_file_moi;
            
            if (move_uploaded_file($file_info['tmp_name'], $upload_path)) {
                $file_dinh_kem_db = $ten_file_moi;
            } else {
                throw new Exception("Lỗi khi upload file.");
            }
        }
        
        // 4. Chèn dữ liệu vào VAN_BAN_DEN
        $stmt_insert = $pdo->prepare("
            INSERT INTO van_ban_den (so_den, nam_den, so_van_ban, ngay_thang_vb, loai_vb_id, trich_yeu, de_xuat_xu_ly, file_dinh_kem, nguoi_nhap_id) 
            VALUES (:so_den, :nam_den, :so_van_ban, :ngay_thang_vb, :loai_vb_id, :trich_yeu, :de_xuat_xu_ly, :file_dinh_kem, :nguoi_nhap_id)
        ");
        $stmt_insert->execute([
            ':so_den' => $so_den,
            ':nam_den' => $nam_den,
            ':so_van_ban' => $so_van_ban,
            ':ngay_thang_vb' => $ngay_thang_vb,
            ':loai_vb_id' => $loai_vb_id,
            ':trich_yeu' => $trich_yeu,
            ':de_xuat_xu_ly' => $de_xuat_xu_ly,
            ':file_dinh_kem' => $file_dinh_kem_db,
            ':nguoi_nhap_id' => $nguoi_nhap_id
        ]);
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => "Lưu văn bản đến thành công! Số đến: {$so_den}/{$nam_den}"]);

    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => "Lỗi: " . $e->getMessage()]);
    }
    exit;
}
?>