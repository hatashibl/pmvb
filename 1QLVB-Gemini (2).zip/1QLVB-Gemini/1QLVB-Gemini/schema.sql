-- Tạo Database (nếu chưa có)
-- CREATE DATABASE quan_ly_van_ban CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE quan_ly_van_ban;

-- 1. Bảng NGUOI_DUNG
CREATE TABLE `nguoi_dung` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `ten_dang_nhap` VARCHAR(50) NOT NULL UNIQUE,
  `ten_day_du` VARCHAR(100) NOT NULL,
  `mat_khau` VARCHAR(255) NOT NULL,
  `chuc_vu` ENUM('admin', 'quan_ly', 'thanh_vien') NOT NULL DEFAULT 'thanh_vien',
  `lan_sai_hien_tai` TINYINT(1) NOT NULL DEFAULT 0,
  `thoi_gian_khoa` DATETIME NULL
);

-- Thêm tài khoản admin mặc định (Mật khẩu: 123456 - Cần được HASH trong code thực tế)
INSERT INTO `nguoi_dung` (`ten_dang_nhap`, `ten_day_du`, `mat_khau`, `chuc_vu`) 
VALUES ('admin', 'Quản trị viên', '$2y$10$Qo.uV/9L1xLw2g2m9nL7W.xQnK1I5.S8B3k5gC8C8Xv0Q/1X8gY8', 'admin'); 
-- Mật khẩu đã được hash bằng PASSWORD_DEFAULT.

-- 2. Bảng LOAI_VAN_BAN
CREATE TABLE `loai_van_ban` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `ten_loai_vb` VARCHAR(100) NOT NULL,
  `ten_viet_tat` VARCHAR(10) NOT NULL UNIQUE,
  `goi_y_trich_yeu` TEXT NULL,
  `goi_y_xu_ly` TEXT NULL
);
ALTER TABLE `loai_van_ban` 
ADD COLUMN `so_cuoi_vb_di` INT(11) NOT NULL DEFAULT 0 
AFTER `goi_y_xu_ly`; 
-- Cột này sẽ lưu trữ số văn bản đi cuối cùng (vd: 123) đã được cấp cho loại văn bản đó.

-- Dữ liệu mẫu cho loại văn bản
INSERT INTO `loai_van_ban` (`ten_loai_vb`, `ten_viet_tat`, `goi_y_trich_yeu`, `goi_y_xu_ly`) 
VALUES 
('Tờ trình', 'TT', 'Trình bày về việc...', 'Xin ý kiến Lãnh đạo'),
('Quyết định', 'QD', 'Ban hành quy chế...', 'Thực hiện theo quy định');

-- 3. Bảng VAN_BAN_DEN
CREATE TABLE `van_ban_den` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `so_den` INT(11) NOT NULL,
  `nam_den` YEAR(4) NOT NULL,
  `so_van_ban` VARCHAR(50) NULL,
  `ngay_thang_vb` DATE NOT NULL,
  `loai_vb_id` INT(11) NOT NULL,
  `trich_yeu` TEXT NOT NULL,
  `de_xuat_xu_ly` TEXT NULL,
  `file_dinh_kem` VARCHAR(255) NULL,
  `nguoi_nhap_id` INT(11) NOT NULL,
  `thoi_gian_nhap` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`loai_vb_id`) REFERENCES `loai_van_ban`(`id`),
  FOREIGN KEY (`nguoi_nhap_id`) REFERENCES `nguoi_dung`(`id`)
);

-- 4. Bảng VAN_BAN_DI
CREATE TABLE `van_ban_di` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `so` VARCHAR(50) NOT NULL,
  `ngay_thang` DATE NOT NULL,
  `loai_vb_id` INT(11) NOT NULL,
  `trich_yeu` TEXT NOT NULL,
  `tra_loi_vb_den_id` INT(11) NULL,
  `file_dinh_kem` VARCHAR(255) NULL,
  `nguoi_nhap_id` INT(11) NOT NULL,
  `thoi_gian_nhap` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`loai_vb_id`) REFERENCES `loai_van_ban`(`id`),
  FOREIGN KEY (`tra_loi_vb_den_id`) REFERENCES `van_ban_den`(`id`),
  FOREIGN KEY (`nguoi_nhap_id`) REFERENCES `nguoi_dung`(`id`)
);

-- 5. Bảng THONG_BAO (Lưu trữ cả thông báo VB và tin nhắn trao đổi)
CREATE TABLE `thong_bao` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `vb_den_id` INT(11) NULL,
  `vb_di_id` INT(11) NULL,
  `nguoi_gui_id` INT(11) NOT NULL,
  `ngay_gio_gui` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `noi_dung` TEXT NULL,
  `file_tra_loi` VARCHAR(255) NULL,
  `parent_id` INT(11) NULL COMMENT 'ID của tin nhắn/VB gốc',
  FOREIGN KEY (`vb_den_id`) REFERENCES `van_ban_den`(`id`),
  FOREIGN KEY (`vb_di_id`) REFERENCES `van_ban_di`(`id`),
  FOREIGN KEY (`nguoi_gui_id`) REFERENCES `nguoi_dung`(`id`),
  FOREIGN KEY (`parent_id`) REFERENCES `thong_bao`(`id`)
);

-- 6. Bảng THONG_BAO_NGUOI_NHAN
CREATE TABLE `thong_bao_nguoi_nhan` (
  `thong_bao_id` INT(11) NOT NULL,
  `nguoi_nhan_id` INT(11) NOT NULL,
  `da_doc` TINYINT(1) NOT NULL DEFAULT 0,
  `thoi_gian_doc` DATETIME NULL,
  PRIMARY KEY (`thong_bao_id`, `nguoi_nhan_id`),
  FOREIGN KEY (`thong_bao_id`) REFERENCES `thong_bao`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`nguoi_nhan_id`) REFERENCES `nguoi_dung`(`id`)
);

-- 7. Bảng CAI_DAT_HE_THONG
CREATE TABLE `cai_dat_he_thong` (
  `key` VARCHAR(50) NOT NULL PRIMARY KEY,
  `value` TEXT NOT NULL
);

-- Dữ liệu cài đặt mặc định
INSERT INTO `cai_dat_he_thong` (`key`, `value`) 
VALUES 
('ten_phan_mem', 'PHẦN MỀM QUẢN LÝ VĂN BẢN'),
('copyright', 'Bản quyền &copy; 2024'),
('nam_hien_hanh', YEAR(NOW()));